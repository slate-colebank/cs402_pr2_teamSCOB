// Slate Colebank and Owen Barenburg
// CSCI 402
// Program 2

public class Main{ 
    public static void main(String[] args) {
        Monkey.run();
    }
}